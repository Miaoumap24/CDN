const GLOBAL_HOME_ADDRESS = 'https://garticphone.com/';

function isInvite() {
    let address = getAddress();
    return address.startsWith('https://garticphone.com/?c') || address.startsWith(GLOBAL_HOME_ADDRESS) && address.includes('?c=')
}

function isHomeOrInvite() {
    return isHome() || isInvite()
}

function isHome() {
    let address = getAddress();
    return address === GLOBAL_HOME_ADDRESS || address.startsWith(GLOBAL_HOME_ADDRESS) && address.length === GLOBAL_HOME_ADDRESS.length + 2
}

function getAddress() {
    return window.location.href;
}

function isPage(searchString) {
    let address = getAddress();
    return address.startsWith(GLOBAL_HOME_ADDRESS) && address.includes(searchString)
}

function isBook() {
    return isPage('book');
}
function isLobby() {
    return isPage('lobby')
}

function isNeitherLobbyOrBook() {
    return !isLobby() && !isBook();
}
function isRank() {
    return isPage('rank')
}
