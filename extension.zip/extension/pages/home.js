const KEY_DISABLED = 'disabled';
const KEY_ENABLED = 'enabled';
let CUSTOM_AVATARS = {}
let GLOBAL_AVATARS = null

// L'URL de ton proxy, assure-toi qu'elle est correcte.
const PROXY_URL = 'https://gartic-proxy.onrender.com';

// L'ID de l'avatar personnalisé que l'extension doit toujours utiliser.
// Remplace 'Timéo-avatar' par l'ID que tu as choisi dans ton fichier index.js.
const MY_CUSTOM_AVATAR_ID = 'xtram';

function getBackgroundImage(name) {
    // Cette fonction ne sert plus à grand-chose avec le proxy, mais on la garde pour la structure
    return `url(${PROXY_URL}/images/avatar/${MY_CUSTOM_AVATAR_ID}.svg)`
}

function replaceAvatarsLobby() {
    if (isNeitherLobbyOrBook()) return
    const userList = document.getElementsByClassName('user');
    for (let user of userList) {
        let name = user.children[1].children[0].textContent.toLowerCase()
        let avatar = user.children[0].children[0]
        if (CUSTOM_AVATARS[name.toLowerCase()] !== undefined) {
            avatar.style.backgroundImage = getBackgroundImage(name)
        }
    }
}

const CUSTOM_AVATAR_RAW = `${PROXY_URL}/images/avatar/${MY_CUSTOM_AVATAR_ID}.svg`

function retrieveUserAvatars() {
    let hasGPMod = document.querySelector('.gp-about_')
    loadAvatars(function (avatars) {
        CUSTOM_AVATARS = {}
        let hasGPModBool = hasGPMod !== null
        if (hasGPModBool) {
            GLOBAL_AVATARS = []
        }
        if (!GLOBAL_AVATARS) {
            fetch(CUSTOM_AVATAR_RAW)
                .then(response => response.json()
                    .then(x => {
                        GLOBAL_AVATARS = x
                        for (let key of Object.keys(GLOBAL_AVATARS)) {
                            CUSTOM_AVATARS[key] = GLOBAL_AVATARS[key]
                        }
                        for (let x of avatars) {
                            CUSTOM_AVATARS[x.name] = x.url
                        }
                    }))
        } else {
            for (let key of Object.keys(GLOBAL_AVATARS)) {
                CUSTOM_AVATARS[key] = GLOBAL_AVATARS[key]
            }
            for (let x of avatars) {
                CUSTOM_AVATARS[x.name] = x.url
            }
        }
    })
}


const observer = new MutationObserver(function (mutations) {

    retrieveUserAvatars();
    handleHomePage()
    mutations.forEach(function () {
        replaceAvatarsLobby()
        replaceAvatarsRank()
        handleBookPage();
    });
});
const config = {
    childList: true, subtree: true
};
observer.observe(document.body, config);
let activateCustomAvatars = KEY_ENABLED

function loadCustomAvatars() {
    return activateCustomAvatars
}

function toUrlString(url) {
    return "url('" + url + "')"
}

function handleBookPage() {
    if (!isBook()) return
    if (loadCustomAvatars() === KEY_DISABLED) replaceAvatarsLobby()
    const drawBalloons = document.getElementsByClassName('drawing');
    for (let draw of drawBalloons) {
        let name = draw.children[1].children[0].textContent.toLowerCase()
        let avatar = draw.children[0].children[0]
        if (CUSTOM_AVATARS[name.toLowerCase()] !== undefined) {
            avatar.style.backgroundImage = getBackgroundImage(name)
        }
    }
    const answerBalloons = document.getElementsByClassName('answer');
    for (let answers of answerBalloons) {
        let name = answers.children[0].children[0].textContent.toLowerCase()
        let avatar = answers.children[1].children[0]
        if (CUSTOM_AVATARS[name.toLowerCase()] !== undefined) {
            avatar.style.backgroundImage = getBackgroundImage(name)
        }
    }
}

function replaceAvatarsRank() {
    if (!isRank()) return
    const userList = document.getElementsByClassName('user');
    for (let user of userList) {
        try {
            let user1 = user.children[0];
            let name = user1.children[2].textContent.toLowerCase()
            let avatar = user1.children[1].children[0]
            if (CUSTOM_AVATARS[name] !== undefined) {
                avatar.style.backgroundImage = getBackgroundImage(name)
            }
        } catch (e) {
        }
    }
    const userList2 = document.getElementsByClassName('user');
    for (let user of userList2) {
        try {
            let name = user.children[1].children[0].textContent.toLowerCase()
            let avatar = user.children[0].children[0]
            if (CUSTOM_AVATARS[name] !== undefined) {
                avatar.style.backgroundImage = getBackgroundImage(name)
            }
        } catch (e) {
        }
    }

}